version 1.0

import "./wdl_structs.wdl"
import "calling/snv_indel_wkf.wdl" as calling
import "alignment_analysis/msi_wkf.wdl" as msi
import "calling/calling.wdl" as callingTasks
import "merge_vcf/merge_vcf_wkf.wdl" as mergeVcf
import "pre_process/qc.wdl" as qc
import "annotate/annotate_wkf.wdl" as annotate
import "variant_analysis/deconstruct_sigs_wkf.wdl" as deconstructSigs
import "tasks/bam_cram_conversion.wdl" as cramConversion
import "tasks/reheader_bam_wkf.wdl" as reheaderBam
import "tasks/utils.wdl" as utils
import "merge_vcf/merge_vcf.wdl" as mergeVcf
import "merge_vcf/merge_chroms_wkf.wdl" as mergeChroms

# ================== COPYRIGHT ================================================
# New York Genome Center
# SOFTWARE COPYRIGHT NOTICE AGREEMENT
# This software and its documentation are copyright (2021) by the New York
# Genome Center. All rights are reserved. This software is supplied without
# any warranty or guaranteed support whatsoever. The New York Genome Center
# cannot be responsible for its use, misuse, or functionality.
#
#    Jennifer M Shelton (jshelton@nygenome.org)
#    James Roche (jroche@nygenome.org)
#    Nico Robine (nrobine@nygenome.org)
#    Timothy Chu (tchu@nygenome.org)
#    Will Hooper (whooper@nygenome.org)
#    Minita Shah
#
# ================== /COPYRIGHT ===============================================


workflow SomaticDNA {
    input {
        Boolean external = false
        String library

        BwaReference bwaReference
        IndexedReference referenceFa

        Boolean production = true

        Array[PairInfo]+ pairInfos
        File mergedChromVcf

        # For Tumor-Normal QC
        File markerBedFile
        File markerTxtFile

        # calling
        Array[String]+ listOfChromsFull
        Array[String]+ listOfChroms
        Array[String]+ callerIntervals
        Array[String]+ exomeCallerIntervals = callerIntervals
        File invertedIntervalListBed
        IndexedTable callRegions
        Map[String, File] chromBedsWgs
        Map[String, File] chromBeds
        File lancetJsonLog
        File mantaJsonLog
        File strelkaJsonLog
        File mutectJsonLog
        File mutectJsonLogFilter
        File configureStrelkaSomaticWorkflow
        File intervalListBed

        String library
        File ponWGSFile
        File ponExomeFile
        IndexedVcf gnomadBiallelic

        # mantis
        File mantisBed

        # annotation:
        String vepGenomeBuild
        Map[String, IndexedVcf] cosmicCodingChrom
        Map[String, IndexedVcf] cosmicNoncodingChrom

        # Public
        Map[String, File] vepCacheChrom
        Map[String, File] annotationsChrom
        File plugins
        File dbNSFPReplacementLogic
        File MaxEntScan
        Map[String, IndexedTable] dbNSFP4Chrom
        Map[String, IndexedTable] dbscSNVChrom
        Map[String, IndexedVcf] gnomadGenomes
        Map[String, IndexedVcf] gnomadExomes
        IndexedReference vepFastaReference

        # Public
        File cancerResistanceMutations
        IndexedVcf deepIntronicsVcf
        IndexedVcf clinvarIntronicsVcf


        # post annotation
        File cosmicCensus

        File ensemblEntrez

        # germline

        File excludeIntervalList
        Array[File] scatterIntervalsHcs

        IndexedVcf MillsAnd1000G
        IndexedVcf omni
        IndexedVcf hapmap
        IndexedVcf onekG
        IndexedVcf dbsnp

        IndexedVcf whitelist
        IndexedVcf nygcAf
        IndexedVcf pgx
        IndexedTable rwgsPgxBed
        IndexedVcf deepIntronicsVcf
        IndexedVcf clinvarIntronicsVcf
        IndexedVcf chdWhitelistVcf

        IndexedVcf germFile

        # signatures
        File cosmicSigs

        # Gridss resources need a lot of fine grained control
        Int gridssPreMemoryGb = 60
        Int gridssFilterMemoryGb = 32
        Boolean gridssHighMem = false
        Boolean mantaHighMem = false
        Boolean mutect2HighMem = false
        
        # need to create docker with gcloud
        File? serviceAccountKey
        String? gcpProject
    }
    if (library == 'Exome') {
        Array[String]+ exomeRunCallerIntervals = exomeCallerIntervals
    }
    
    if (library == 'WGS') {
        Array[String]+ wgsRunCallerIntervals = callerIntervals
    }
    Array[String]+ runCallerIntervals = select_first([exomeRunCallerIntervals, wgsRunCallerIntervals])

    scatter(pairInfo in pairInfos) {
    
    call utils.SplitVcf {
        input:
            vcf=mergedChromVcf,
            prefix="merged.plus.lancet.",
            diskSize = (ceil(size(mergedChromVcf, "GB")) * 3) + 10,
            maxRows = 1000,
            maxSplits = 30,
            minSplits = 2
    }
    #  =================================================================
    #                     Merge columns
    #  =================================================================
    scatter(vcf in SplitVcf.splitVcfs) {
        String splitId = sub(basename(vcf), ".vcf$", "")
        Int diskSize = ceil( size(pairInfo.tumorFinalBam.bam, "GB") + size(pairInfo.normalFinalBam.bam, "GB")) + 20
        call mergeVcf.PostProcessMerged {
            input:
                chrom = splitId,
                tumorId = pairInfo.tumorId,
                normalId = pairInfo.normalId,
                pairName = pairInfo.pairId,
                supportedChromVcf = vcf,
                normalFinalBam = pairInfo.normalFinalBam,
                tumorFinalBam = pairInfo.tumorFinalBam,
                ponFile = ponWGSFile,
                diskSize = diskSize,
                serviceAccountKey = serviceAccountKey,
                gcpProject = gcpProject
            }
        }
        
        call mergeChroms.MergeChroms {
            input:
                tumorId=pairInfo.tumorId,
                normalId=pairInfo.normalId,
                pairName=pairInfo.pairId,
                referenceFa=referenceFa,
                finalChromVcf=PostProcessMerged.finalChromVcf,
                
        }
        
        call annotate.Annotate {
            input:
                unannotatedVcf = MergeChroms.unannotatedVcf,
                referenceFa = referenceFa,
                production = production,
                tumorId = pairInfo.tumorId,
                normalId = pairInfo.normalId,
                pairName = pairInfo.pairId,
                listOfChroms = listOfChroms,
                vepGenomeBuild = vepGenomeBuild,
                cosmicCodingChrom = cosmicCodingChrom,
                cosmicNoncodingChrom = cosmicNoncodingChrom,
                dbNSFPReplacementLogic = dbNSFPReplacementLogic,
                MaxEntScan = MaxEntScan,
                dbNSFP4Chrom = dbNSFP4Chrom,
                dbscSNVChrom = dbscSNVChrom,
                gnomadGenomes = gnomadGenomes,
                gnomadExomes = gnomadExomes,
                # Public
                cancerResistanceMutations = cancerResistanceMutations,
                vepCacheChrom = vepCacheChrom,
                annotationsChrom = annotationsChrom,
                plugins = plugins,
                vepFastaReference = vepFastaReference,
                # Public
                deepIntronicsVcf = deepIntronicsVcf,
                clinvarIntronicsVcf = clinvarIntronicsVcf,
                # post annotation
                cosmicCensus = cosmicCensus,
                ensemblEntrez = ensemblEntrez,
                library = library
        }

        File runMainVcf = Annotate.pairVcfInfo.mainVcf
        File runSupplementalVcf = Annotate.pairVcfInfo.supplementalVcf
        File runVcfAnnotatedTxt = Annotate.pairVcfInfo.vcfAnnotatedTxt

        call deconstructSigs.DeconstructSig {
            input:
                pairId = pairInfo.pairId,
                mainVcf = MergeChroms.unannotatedVcf,
                cosmicSigs = cosmicSigs,
                vepGenomeBuild = vepGenomeBuild
        }
   }

    output {

        # CNV SV output and SNV INDELs
        Array[File] mainVcf = runMainVcf
        Array[File] supplementalVcf = runSupplementalVcf
        Array[File] vcfAnnotatedTxt = runVcfAnnotatedTxt
        # sigs
        Array[File] sigs = DeconstructSig.sigs
        Array[File] counts = DeconstructSig.counts
        Array[File] sig_input = DeconstructSig.sigInput
        Array[File] reconstructed = DeconstructSig.reconstructed
        Array[File] diff = DeconstructSig.diff

    }
}
