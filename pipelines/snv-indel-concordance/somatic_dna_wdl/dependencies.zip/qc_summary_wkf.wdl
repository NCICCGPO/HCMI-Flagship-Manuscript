version 1.0

import "wdl_structs.wdl"
import "pre_process/qc.wdl" as qc
import "test/tests.wdl" as tests
import "pre_process/conpair_wkf.wdl" as conpair


struct ContaminationSet {
        String pairId
        String tumorId
        String normalId
        File normalContaminationTable
        File normalPileupsTable
        File tumorContaminationTable
        File tumorPileupsTable
        File normalPileupsConpair
        File tumorPileupsConpair
}

workflow SummarizeQc {
    # command
    input {
        String name
        Array[ContaminationSet] contaminationSets
        File markerTxtFile
        
        # flagStat
        Array[File] flagStat
        # collectWgsMetrics
        Array[File] collectWgsMetrics
        # insertSizeMetrics
        Array[File] insertSizeMetrics
        # qualityByCycleMetrics
        Array[File] qualityByCycleMetrics
        
        # Bam finalNormalBam
        # Bam finalTumorBam
        # IndexedReference referenceFa

    }
    
    scatter (contaminationSet in contaminationSets) {
        call qc.CalculateContaminationPaired {
            input:
                pairName = contaminationSet.pairId,
                pileupsNormalTable = contaminationSet.normalPileupsTable,
                pileupsTumorTable = contaminationSet.tumorPileupsTable,
                memoryGb = 16,
                threads = 1
        }
        
        call conpair.Conpair {
            input:
                tumorPileupsConpair = contaminationSet.tumorPileupsConpair,
                normalPileupsConpair = contaminationSet.normalPileupsConpair,
                tumor = contaminationSet.tumorId,
                normal = contaminationSet.normalId,
                pairName = contaminationSet.pairId,
                markerTxtFile = markerTxtFile
        }
    }
    
    call tests.ConcateTables as calculateContaminationConcateTables {
        input:
            tables = CalculateContaminationPaired.contaminationTable,
            outputTablePath = "~{name}.summaryCalculateContamination.csv"
    }
    
    call tests.ConcateTables as concordanceAllConcateTables {
        input:
            tables = Conpair.concordanceAll,
            outputTablePath = "~{name}.summaryConcordanceAll.csv"
    }
    
    call tests.ConcateTables as concordanceHomozConcateTables {
        input:
            tables = Conpair.concordanceHomoz,
            outputTablePath = "~{name}.summaryConcordanceHomoz.csv"
    }
    
    call tests.ConcateTables as conpairContaminationConcateTables {
        input:
            tables = Conpair.contamination,
            outputTablePath = "~{name}.summaryConpairContamination.csv"
    }
        
    call tests.SummarizeQualityByCycle {
        input:
            qualityByCycleMetrics = qualityByCycleMetrics,
            name = name
    }
    
    call tests.SummarizeFlagStat {
        input:
            flagStats = flagStat,
            name = name
    }
    
    call tests.SummarizeCollectWgsMetrics {
        input:
            collectWgsMetrics = collectWgsMetrics,
            name = name
    }
    
    call tests.SummarizeInsertSizeMetrics {
        input:
            insertSizeMetrics = insertSizeMetrics,
            name = name
    }
    
    output {
        File qualityByCycleTable = SummarizeQualityByCycle.qualityByCycleTable
        File insertSizeTable = SummarizeInsertSizeMetrics.insertSizeTable
        File coverageTable = SummarizeCollectWgsMetrics.coverageTable
        File flagStatTable = SummarizeFlagStat.flagStatTable
        
        File calculateContamination = calculateContaminationConcateTables.outputTable
        File concordanceAll = concordanceAllConcateTables.outputTable
        File concordanceHomoz = concordanceHomozConcateTables.outputTable
        File conpairContamination = conpairContaminationConcateTables.outputTable
    }
}
