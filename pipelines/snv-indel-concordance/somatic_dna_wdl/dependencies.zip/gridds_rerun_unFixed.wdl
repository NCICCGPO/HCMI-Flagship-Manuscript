version 1.0

import "calling/calling.wdl" as calling
import "merge_vcf/merge_vcf.wdl" as mergeVcf
import "wdl_structs.wdl"

workflow GridssFilter {
    input {
        String bsGenome
        File ponTarGz

        Int threads = 8
        
        Int preMemoryGb = 60
        Int filterMemoryGb = 32
        
        String pairName = "COLO-829-NovaSeq-Rep1-80x--COLO-829BL-NovaSeq-Rep1-40x"
        String normal = "COLO-829BL-NovaSeq-Rep1-40x"
        String tumor = "COLO-829-NovaSeq-Rep1-80x"
        # unFixedHeader
        File gridssUnfilteredVcf = "gs://nygc-comp-s-fd4e-workspace/SomaticDNA/56731910-de48-427c-8a00-a03330db82b9/call-Calling/shard-0/Calling/7a8b99a2-7fae-4e6b-9cdb-538336096ecf/call-Gridss/Gridss/80a7a795-4c90-4247-a792-1f67d99941e2/call-FilterNonChroms/cacheCopy/COLO-829-NovaSeq-Rep1-80x--COLO-829BL-NovaSeq-Rep1-40x.sv.gridss.unfiltered.chroms.vcf"
    }
    
    call calling.GridssFilter {
        input:
            threads = threads,
            memoryGb = filterMemoryGb,
            pairName = pairName,
            bsGenome = bsGenome,
            ponTarGz = ponTarGz,
            gridssUnfilteredVcf = gridssUnfilteredVcf,
            diskSize = 35
    }
    
    call calling.ReorderVcfColumns as filteredReorderVcfColumns {
        input:
            tumor = tumor,
            normal = normal,
            rawVcf = GridssFilter.gridssVcf.vcf,
            orderedVcfPath = "~{pairName}.sv.gridss.vcf",
            memoryGb = 4,
            diskSize = 10
    }
    
    call mergeVcf.CompressVcf {
        input:
            vcf = filteredReorderVcfColumns.orderedVcf,
            memoryGb = 4
    }

    call mergeVcf.IndexVcf {
        input:
            vcfCompressed = CompressVcf.vcfCompressed
    }
    
    output {
        IndexedVcf gridssVcf = IndexVcf.vcfCompressedIndexed
    }
}
