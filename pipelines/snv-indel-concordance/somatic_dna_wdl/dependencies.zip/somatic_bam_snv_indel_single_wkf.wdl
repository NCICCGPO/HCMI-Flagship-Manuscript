version 1.0

import "./wdl_structs.wdl"
import "calling/snv_indel_wkf.wdl" as calling
import "alignment_analysis/msi_wkf.wdl" as msi
import "calling/calling.wdl" as callingTasks
import "merge_vcf/merge_vcf_wkf.wdl" as mergeVcf
import "pre_process/qc.wdl" as qc
import "annotate/annotate_wkf.wdl" as annotate
import "variant_analysis/deconstruct_sigs_wkf.wdl" as deconstructSigs
import "tasks/bam_cram_conversion.wdl" as cramConversion
import "tasks/reheader_bam_wkf.wdl" as reheaderBam
import "tasks/utils.wdl" as utils

# ================== COPYRIGHT ================================================
# New York Genome Center
# SOFTWARE COPYRIGHT NOTICE AGREEMENT
# This software and its documentation are copyright (2021) by the New York
# Genome Center. All rights are reserved. This software is supplied without
# any warranty or guaranteed support whatsoever. The New York Genome Center
# cannot be responsible for its use, misuse, or functionality.
#
#    Jennifer M Shelton (jshelton@nygenome.org)
#    James Roche (jroche@nygenome.org)
#    Nico Robine (nrobine@nygenome.org)
#    Timothy Chu (tchu@nygenome.org)
#    Will Hooper (whooper@nygenome.org)
#    Minita Shah
#
# ================== /COPYRIGHT ===============================================


workflow SomaticDNA {
    input {
        Boolean external = false
        String library

        BwaReference bwaReference
        IndexedReference referenceFa

        Boolean production = true

        Array[PairInfo]+ pairInfos

        # For Tumor-Normal QC
        File markerBedFile
        File markerTxtFile

        # calling
        Array[String]+ listOfChromsFull
        Array[String]+ listOfChroms
        Array[String]+ callerIntervals
        Array[String]+ exomeCallerIntervals = callerIntervals
        File invertedIntervalListBed
        IndexedTable callRegions
        Array[File] splitBedsWgs
        Map[String, File] chromBeds
        File lancetJsonLog
        File mantaJsonLog
        File strelkaJsonLog
        File mutectJsonLog
        File mutectJsonLogFilter
        File configureStrelkaSomaticWorkflow
        File intervalListBed

        String library
        File ponWGSFile
        File ponExomeFile
        IndexedVcf gnomadBiallelic

        # mantis
        File mantisBed

        # annotation:
        String vepGenomeBuild
        Map[String, IndexedVcf] cosmicCodingChrom
        Map[String, IndexedVcf] cosmicNoncodingChrom

        # Public
        Map[String, File] vepCacheChrom
        Map[String, File] annotationsChrom
        File plugins
        File dbNSFPReplacementLogic
        File MaxEntScan
        Map[String, IndexedTable] dbNSFP4Chrom
        Map[String, IndexedTable] dbscSNVChrom
        Map[String, IndexedVcf] gnomadGenomes
        Map[String, IndexedVcf] gnomadExomes
        IndexedReference vepFastaReference

        # Public
        File cancerResistanceMutations
        IndexedVcf deepIntronicsVcf
        IndexedVcf clinvarIntronicsVcf


        # post annotation
        File cosmicCensus

        File ensemblEntrez

        # germline

        File excludeIntervalList
        Array[File] scatterIntervalsHcs

        IndexedVcf MillsAnd1000G
        IndexedVcf omni
        IndexedVcf hapmap
        IndexedVcf onekG
        IndexedVcf dbsnp

        IndexedVcf whitelist
        IndexedVcf nygcAf
        IndexedVcf pgx
        IndexedTable rwgsPgxBed
        IndexedVcf deepIntronicsVcf
        IndexedVcf clinvarIntronicsVcf
        IndexedVcf chdWhitelistVcf


        # signatures
        File cosmicSigs

        # Gridss resources need a lot of fine grained control
        Int gridssPreMemoryGb = 60
        Int gridssFilterMemoryGb = 32
        Boolean gridssHighMem = false
        Boolean mantaHighMem = false
        Boolean mutect2HighMem = false
        # need to create docker with gcloud
        File? serviceAccountKey
        String? gcpProject
    }
    if (library == 'Exome') {
        Array[String]+ exomeRunCallerIntervals = exomeCallerIntervals
    }
    
    if (library == 'WGS') {
        Array[String]+ wgsRunCallerIntervals = callerIntervals
    }
    Array[String]+ runCallerIntervals = select_first([exomeRunCallerIntervals, wgsRunCallerIntervals])

    scatter(pairInfo in pairInfos) {
        call calling.Calling {
            input:
                mantaJsonLog = mantaJsonLog,
                lancetJsonLog = lancetJsonLog,
                mutectJsonLog = mutectJsonLog,
                mutectJsonLogFilter = mutectJsonLogFilter,
                strelkaJsonLog = strelkaJsonLog,
                configureStrelkaSomaticWorkflow = configureStrelkaSomaticWorkflow,
                intervalListBed = intervalListBed,
                callerIntervals = runCallerIntervals,
                invertedIntervalListBed = invertedIntervalListBed,
                pairInfo = pairInfo,
                listOfChroms = listOfChroms,
                listOfChromsFull = listOfChromsFull,
                referenceFa = referenceFa,
                callRegions = callRegions,
                bwaReference = bwaReference,
                splitBedsWgs = splitBedsWgs,
                chromBeds = chromBeds,
                mantaHighMem = mantaHighMem,
                mutect2HighMem = mutect2HighMem,
                library = library,
                serviceAccountKey = serviceAccountKey,
                gcpProject = gcpProject
        }

        call msi.Msi {
            input:
                normal = pairInfo.normalId,
                pairName = pairInfo.pairId,
                mantisBed = mantisBed,
                intervalListBed = intervalListBed,
                referenceFa = referenceFa,
                tumorFinalBam = pairInfo.tumorFinalBam,
                normalFinalBam = pairInfo.normalFinalBam
        }
        
        if (library == 'Exome') {
            call utils.CreateBlankFile as createVcf {
                input:
                    fileId = "~{pairInfo.pairId}_nonVcfFile_"
            }
        }
        
        File filteredMantaSVFinal = select_first([Calling.filteredMantaSV, createVcf.blankFile])

        PreMergedPairVcfInfo preMergedPairVcfInfo = object {
            pairId : pairInfo.pairId,
            filteredMantaSV : filteredMantaSVFinal,
            strelka2Snv : Calling.strelka2Snv,
            strelka2Indel : Calling.strelka2Indel,
            mutect2 : Calling.mutect2,
            lancet : Calling.lancet,
            tumor : pairInfo.tumorId,
            normal : pairInfo.normalId,
            tumorFinalBam : pairInfo.tumorFinalBam,
            normalFinalBam : pairInfo.normalFinalBam

        }

        if (library == 'Exome') {
            call mergeVcf.MergeVcf as MergeVcfExome {
                input:
                    external = external,
                    library = library,
                    preMergedPairVcfInfo = preMergedPairVcfInfo,
                    referenceFa = referenceFa,
                    listOfChroms = listOfChroms,
                    intervalListBed = intervalListBed,
                    ponFile = ponExomeFile,
                    serviceAccountKey = serviceAccountKey,
                    gcpProject = gcpProject
            }
        }
        
        if (library == 'WGS') {
            call mergeVcf.MergeVcf as MergeVcfWgs {
                input:
                    external = external,
                    library = library,
                    preMergedPairVcfInfo = preMergedPairVcfInfo,
                    referenceFa = referenceFa,
                    listOfChroms = listOfChroms,
                    intervalListBed = intervalListBed,
                    ponFile = ponWGSFile,
                    serviceAccountKey = serviceAccountKey,
                    gcpProject = gcpProject
            }
        }

        File mergedVcf = select_first([MergeVcfExome.mergedVcf, MergeVcfWgs.mergedVcf])
        
        call annotate.Annotate {
            input:
                unannotatedVcf = mergedVcf,
                referenceFa = referenceFa,
                production = production,
                tumorId = pairInfo.tumorId,
                normalId = pairInfo.normalId,
                pairName = pairInfo.pairId,
                listOfChroms = listOfChroms,
                vepGenomeBuild = vepGenomeBuild,
                cosmicCodingChrom = cosmicCodingChrom,
                cosmicNoncodingChrom = cosmicNoncodingChrom,
                dbNSFPReplacementLogic = dbNSFPReplacementLogic,
                MaxEntScan = MaxEntScan,
                dbNSFP4Chrom = dbNSFP4Chrom,
                dbscSNVChrom = dbscSNVChrom,
                gnomadGenomes = gnomadGenomes,
                gnomadExomes = gnomadExomes,
                # Public
                cancerResistanceMutations = cancerResistanceMutations,
                vepCacheChrom = vepCacheChrom,
                annotationsChrom = annotationsChrom,
                plugins = plugins,
                vepFastaReference = vepFastaReference,
                # Public
                deepIntronicsVcf = deepIntronicsVcf,
                clinvarIntronicsVcf = clinvarIntronicsVcf,
                # post annotation
                cosmicCensus = cosmicCensus,
                ensemblEntrez = ensemblEntrez,
                library = library
        }

        File runMainVcf = Annotate.pairVcfInfo.mainVcf
        File runSupplementalVcf = Annotate.pairVcfInfo.supplementalVcf
        File runVcfAnnotatedTxt = Annotate.pairVcfInfo.vcfAnnotatedTxt

        call deconstructSigs.DeconstructSig {
            input:
                pairId = pairInfo.pairId,
                mainVcf = mergedVcf,
                cosmicSigs = cosmicSigs,
                vepGenomeBuild = vepGenomeBuild
        }
   }

    output {

        # CNV SV output and SNV INDELs
        Array[File] mainVcf = runMainVcf
        Array[File] supplementalVcf = runSupplementalVcf
        Array[File] vcfAnnotatedTxt = runVcfAnnotatedTxt
        Array[File?] filteredMantaSV = Calling.filteredMantaSV
        Array[File] strelka2Snv = Calling.strelka2Snv
        Array[File] strelka2Indel = Calling.strelka2Indel
        Array[File] mutect2 = Calling.mutect2
        Array[File] lancet = Calling.lancet
        # MSI
        Array[File] mantisWxsKmerCountsFinal = Msi.mantisWxsKmerCountsFinal
        Array[File] mantisWxsKmerCountsFiltered = Msi.mantisWxsKmerCountsFiltered
        Array[File] mantisExomeTxt = Msi.mantisExomeTxt
        Array[File] mantisStatusFinal = Msi.mantisStatusFinal
        # sigs
        Array[File] sigs = DeconstructSig.sigs
        Array[File] counts = DeconstructSig.counts
        Array[File] sig_input = DeconstructSig.sigInput
        Array[File] reconstructed = DeconstructSig.reconstructed
        Array[File] diff = DeconstructSig.diff

    }
}
