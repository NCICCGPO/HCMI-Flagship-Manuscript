version 1.0

import "wdl_structs.wdl"
import "pre_process/qc_exome_wkf_tmp.wdl" as qc

# breaking full pipeline to just handle the preprocessing steps to test aligners
# input is a list of samples and there fastq information, no pairing info needed

# ================== COPYRIGHT ================================================
# New York Genome Center
# SOFTWARE COPYRIGHT NOTICE AGREEMENT
# This software and its documentation are copyright (2021) by the New York
# Genome Center. All rights are reserved. This software is supplied without
# any warranty or guaranteed support whatsoever. The New York Genome Center
# cannot be responsible for its use, misuse, or functionality.
#
#    Jennifer M Shelton (jshelton@nygenome.org)
#    James Roche (jroche@nygenome.org)
#    Nico Robine (nrobine@nygenome.org)
#    Timothy Chu (tchu@nygenome.org)
#    Will Hooper (whooper@nygenome.org)
#    Minita Shah
#
# ================== /COPYRIGHT ===============================================


workflow QcExomeWrapper {
    input {
        IndexedReference referenceFa
        IndexedVcf gnomadBiallelic
        File chromLengths
        File intervalList
        File refSeqGeneList
        Array[SampleBamInfo] bamInfos
        File markerBedFile

        Int preprocessAdditionalDiskSize = 20
    }
    scatter (bamInfo in bamInfos) {
        call qc.QcMetricsExome {
            input:
                finalBam = bamInfo.finalBam,
                referenceFa = referenceFa,
                sampleId = bamInfo.sampleId,
                intervalList = intervalList,
                refSeqGeneList = refSeqGeneList,
                chromLengths = chromLengths,
                gnomadBiallelic = gnomadBiallelic,
                markerBedFile = markerBedFile,
                outputDir = "Sample_~{bamInfo.sampleId}/qc"
        }
    }

    output {
        # QC
        Array[File] depthOfCoverageSampleSummary=QcMetricsExome.depthOfCoverageSampleSummary
        Array[File] depthOfCoverageSampleStatistics=QcMetricsExome.depthOfCoverageSampleStatistics
        Array[File] depthOfCoverageSampleGeneSummary=QcMetricsExome.depthOfCoverageSampleGeneSummary
    }

}
