version 1.0

import "wdl_structs.wdl"
import "pre_process/qc.wdl" as qc

# breaking full pipeline to just handle the preprocessing steps to test aligners
# input is a list of samples and there fastq information, no pairing info needed

# ================== COPYRIGHT ================================================
# New York Genome Center
# SOFTWARE COPYRIGHT NOTICE AGREEMENT
# This software and its documentation are copyright (2021) by the New York
# Genome Center. All rights are reserved. This software is supplied without
# any warranty or guaranteed support whatsoever. The New York Genome Center
# cannot be responsible for its use, misuse, or functionality.
#
#    Jennifer M Shelton (jshelton@nygenome.org)
#    James Roche (jroche@nygenome.org)
#    Nico Robine (nrobine@nygenome.org)
#    Timothy Chu (tchu@nygenome.org)
#    Will Hooper (whooper@nygenome.org)
#    Minita Shah
#
# ================== /COPYRIGHT ===============================================


workflow QcWrapper {
    input {
        File randomIntervals
        IndexedReference referenceFa
        String sampleId
        Bam finalBam
        Boolean local = true
    }
    Int additionalDiskSize = 50
    Int diskSize = ceil((size(finalBam.bam, "GB") + size(finalBam.bamIndex, "GB"))) +
                      additionalDiskSize
                      
    if (local) {
        Int localMemoryGb = 48
    }
    if (!local) {
        Int cloudMemoryGb = 16
    }
    Int runMemoryGb = select_first([localMemoryGb, cloudMemoryGb])
    call qc.CollectWgsMetrics {
        input:
            referenceFa = referenceFa,
            randomIntervals = randomIntervals,
            inputBam = finalBam,
            sampleId = sampleId,
            outputDir = "Sample_~{sampleId}/qc",
            memoryGb = runMemoryGb,
            diskSize = diskSize
    }
    output {
        # QC
        File collectWgsMetrics = CollectWgsMetrics.collectWgsMetrics
    }

}
