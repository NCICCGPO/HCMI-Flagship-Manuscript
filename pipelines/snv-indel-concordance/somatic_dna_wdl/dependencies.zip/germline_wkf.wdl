version 1.0

import "wdl_structs.wdl"
import "alignment_analysis/alignment_analysis.wdl" as alignmentAnalysis
import "germline/germline_wkf.wdl" as germline
import "annotate/germline_annotate_wkf.wdl" as germlineAnnotate
import "baf/baf_wkf.wdl" as baf
import "tasks/bam_cram_conversion.wdl" as cramConversion
import "tasks/reheader_bam_wkf.wdl" as reheaderBam
import "tasks/utils.wdl" as utils

# ================== COPYRIGHT ================================================
# New York Genome Center
# SOFTWARE COPYRIGHT NOTICE AGREEMENT
# This software and its documentation are copyright (2021) by the New York
# Genome Center. All rights are reserved. This software is supplied without
# any warranty or guaranteed support whatsoever. The New York Genome Center
# cannot be responsible for its use, misuse, or functionality.
#
#    Jennifer M Shelton (jshelton@nygenome.org)
#    Nico Robine (nrobine@nygenome.org)
#    Minita Shah (mshah@nygenome.org)
#    Timothy Chu (tchu@nygenome.org)
#    Will Hooper (whooper@nygenome.org)
#
# ================== /COPYRIGHT ===============================================

workflow GermlineAll {
    # command 
    input {
        Array[PairInfo]+ pairInfos
        Array[SampleBamInfo]+ normalSampleBamInfos

        IndexedReference referenceFa
        Array[String]+ listOfChroms

        Boolean production = true

        File excludeIntervalList
        Array[File] scatterIntervalsHcs

        IndexedVcf MillsAnd1000G
        IndexedVcf hapmap
        IndexedVcf omni
        IndexedVcf onekG
        IndexedVcf dbsnp

        IndexedVcf whitelist
        IndexedVcf nygcAf
        IndexedVcf pgx
        IndexedTable rwgsPgxBed
        IndexedVcf deepIntronicsVcf
        IndexedVcf clinvarIntronicsVcf
        IndexedVcf chdWhitelistVcf

        # annotation:
        String vepGenomeBuild
        Map[String, IndexedVcf] cosmicCodingChrom
        Map[String, IndexedVcf] cosmicNoncodingChrom
        Array[String]+ listOfChroms

        # Public
        Map[String, File] vepCacheChrom
        Map[String, File] annotationsChrom
        File plugins
        File dbNSFPReplacementLogic
        File MaxEntScan
        Map[String, IndexedTable] dbNSFP4Chrom
        Map[String, IndexedTable] dbscSNVChrom
        Map[String, IndexedVcf] gnomadGenomes
        Map[String, IndexedVcf] gnomadExomes
        IndexedReference vepFastaReference
        
        # Public
        File cancerResistanceMutations
        IndexedVcf deepIntronicsVcf
        IndexedVcf clinvarIntronicsVcf
        
        # post annotation
        File cosmicCensus
        
        File ensemblEntrez
        String library
        
        Boolean highMem = false
        
        # need to create docker with gcloud
        File? serviceAccountKey
        String? gcpProject
    }
    
    # need to find UNIQUE bams (don't convert if part of more than one pair)
    call cramConversion.UniqueBams as uniqueBams {
        input:
            pairInfosJson = write_json(pairInfos)
    }
    
    scatter(bamInfo in uniqueBams.uniqueBams) {
        String alignmentFilename = basename(bamInfo.finalBam.bam)
        String cramAlignmentFilename = sub(basename(bamInfo.finalBam.bam), ".bam$", ".cram")
        if (alignmentFilename == cramAlignmentFilename) {
            String fileTypeCram = "cram"
        }
        if (alignmentFilename != cramAlignmentFilename) {
            String fileTypeBam = "bam"
        }
        String fileType = select_first([fileTypeCram, fileTypeBam])
        
        call reheaderBam.Reheader {
            input:
                finalBam = bamInfo.finalBam,
                referenceFa = referenceFa,
                sampleId = bamInfo.sampleId
        }
        
        String newAlignmentFilename = basename(Reheader.sampleBamMatched.bam)
        if (alignmentFilename == newAlignmentFilename) {
            if (fileType == "cram") {
                Cram renamedFinalCram = object {
                    cram : Reheader.sampleBamMatched.bam,
                    cramIndex : Reheader.sampleBamMatched.bamIndex,
                }
                call cramConversion.SamtoolsCramToBam as cramToBam {
                    input:
                        inputCram = renamedFinalCram,
                        referenceFa = referenceFa,
                        sampleId = bamInfo.sampleId,
                        diskSize = (ceil(size(renamedFinalCram.cram, "GB") * 3)) + 20
                }
                Bam inputSampleBamMatch = select_first([cramToBam.bamInfo.finalBam, Reheader.sampleBamMatched])
            }
        }
        
        Bam inputSampleBamMatched = select_first([inputSampleBamMatch, Reheader.sampleBamMatched])
      String uniqueSampleIds = bamInfo.sampleId
    }

    scatter (normalSampleBamInfo in normalSampleBamInfos) {
        String normalSampleIds = normalSampleBamInfo.sampleId
        # using small disk size because the file is not localized (on servers that support this)
        Int basicDiskSize = 4
        
        call utils.GetIndex as normalGetIndex {
            input:
                sampleIds = uniqueSampleIds,
                sampleId = normalSampleBamInfo.sampleId
        }

        call alignmentAnalysis.GetSampleName {
            input:
                finalBam = inputSampleBamMatched[normalGetIndex.index].bam,
                finalBai = inputSampleBamMatched[normalGetIndex.index].bamIndex,
                referenceFa = referenceFa,
                diskSize = basicDiskSize
        }
        
        call germline.Germline {
            input:
                finalBam = inputSampleBamMatched[normalGetIndex.index],
                normal = normalSampleBamInfo.sampleId,
                outputPrefix = normalSampleBamInfo.sampleId,
                referenceFa = referenceFa,
                listOfChroms = listOfChroms,
                MillsAnd1000G = MillsAnd1000G,
                hapmap = hapmap,
                omni = omni,
                onekG = onekG,
                dbsnp = dbsnp,
                nygcAf = nygcAf,
                excludeIntervalList = excludeIntervalList,
                scatterIntervalsHcs = scatterIntervalsHcs,
                pgx = pgx,
                rwgsPgxBed = rwgsPgxBed,
                whitelist = whitelist,
                chdWhitelistVcf = chdWhitelistVcf,
                deepIntronicsVcf = deepIntronicsVcf,
                clinvarIntronicsVcf = clinvarIntronicsVcf,
                highMem = highMem
        }
        
        call germlineAnnotate.GermlineAnnotate as filteredGermlineAnnotate {
            input:
                unannotatedVcf = Germline.haplotypecallerFinalFiltered,
                production = production,
                referenceFa = referenceFa,
                normal = normalSampleBamInfo.sampleId,
                listOfChroms = listOfChroms,
                vepGenomeBuild = vepGenomeBuild,
                cosmicCodingChrom = cosmicCodingChrom,
                cosmicNoncodingChrom = cosmicNoncodingChrom,
                dbNSFPReplacementLogic = dbNSFPReplacementLogic,
                MaxEntScan = MaxEntScan,
                dbNSFP4Chrom = dbNSFP4Chrom,
                dbscSNVChrom = dbscSNVChrom,
                gnomadGenomes = gnomadGenomes,
                gnomadExomes = gnomadExomes,
                # Public
                cancerResistanceMutations = cancerResistanceMutations,
                vepCacheChrom = vepCacheChrom,
                annotationsChrom = annotationsChrom,
                plugins = plugins,
                vepFastaReference = vepFastaReference,
                # Public
                deepIntronicsVcf = deepIntronicsVcf,
                clinvarIntronicsVcf = clinvarIntronicsVcf,
                # post annotation
                cosmicCensus = cosmicCensus,
                ensemblEntrez = ensemblEntrez,
                library = library
        }

        call germlineAnnotate.GermlineAnnotate as unFilteredGermlineAnnotate {
            input:
                unannotatedVcf = Germline.haplotypecallerVcf,
                                    production = production,
                referenceFa = referenceFa,
                normal = normalSampleBamInfo.sampleId,
                listOfChroms = listOfChroms,
                vepGenomeBuild = vepGenomeBuild,
                cosmicCodingChrom = cosmicCodingChrom,
                cosmicNoncodingChrom = cosmicNoncodingChrom,
                dbNSFPReplacementLogic = dbNSFPReplacementLogic,
                MaxEntScan = MaxEntScan,
                dbNSFP4Chrom = dbNSFP4Chrom,
                dbscSNVChrom = dbscSNVChrom,
                gnomadGenomes = gnomadGenomes,
                gnomadExomes = gnomadExomes,
                # Public
                cancerResistanceMutations = cancerResistanceMutations,
                vepCacheChrom = vepCacheChrom,
                annotationsChrom = annotationsChrom,
                plugins = plugins,
                vepFastaReference = vepFastaReference,
                # Public
                deepIntronicsVcf = deepIntronicsVcf,
                clinvarIntronicsVcf = clinvarIntronicsVcf,
                # post annotation
                cosmicCensus = cosmicCensus,
                ensemblEntrez = ensemblEntrez,
                library = library
        }
    }
    
    scatter(pairInfo in pairInfos) {
        call utils.GetIndex as germlineGetIndex {
            input:
                sampleIds = uniqueSampleIds,
                sampleId = pairInfo.normalId
        }
        
        call utils.GetIndex as tumorGetIndex {
            input:
                sampleIds = uniqueSampleIds,
                sampleId = pairInfo.tumorId
        }

        call baf.Baf {
            input:
                referenceFa = referenceFa,
                pairName = pairInfo.pairId,
                sampleId = pairInfo.normalId,
                tumorFinalBam = inputSampleBamMatched[tumorGetIndex.index],
                normalFinalBam = inputSampleBamMatched[germlineGetIndex.index],
                germlineVcf = unFilteredGermlineAnnotate.haplotypecallerAnnotatedVcf[germlineGetIndex.index],
                serviceAccountKey = serviceAccountKey,
                gcpProject = gcpProject
        }
    }

    output {
        Array[File?] alleleCountsTxt = Baf.alleleCountsTxt
        Array[IndexedVcf] haplotypecallerVcf = Germline.haplotypecallerVcf 
        Array[IndexedVcf] haplotypecallerFinalFiltered = Germline.haplotypecallerFinalFiltered 
        Array[File] filteredHaplotypecallerAnnotatedVcf = filteredGermlineAnnotate.haplotypecallerAnnotatedVcf
        Array[File] haplotypecallerAnnotatedVcf = unFilteredGermlineAnnotate.haplotypecallerAnnotatedVcf
    }
    
}
