version 1.0

import "calling/calling.wdl" as calling
import "wdl_structs.wdl"

workflow GridssFilter {
    input {
        String bsGenome
        File ponTarGz

        Int threads = 8
        
        Int preMemoryGb = 60
        Int filterMemoryGb = 32
        
        String pairName = "COLO-829-NovaSeq-Rep1-80x--COLO-829BL-NovaSeq-Rep1-40x"
        # fixedHeader
        File gridssUnfilteredVcf = "gs://nygc-comp-s-fd4e-input/somatic/COLO-829-NovaSeq-Rep1-80x--COLO-829BL-NovaSeq-Rep1-40x.sv.gridss.unfiltered.chroms.vcf"
    }
    
    call calling.GridssFilter {
        input:
            threads = threads,
            memoryGb = filterMemoryGb,
            pairName = pairName,
            bsGenome = bsGenome,
            ponTarGz = ponTarGz,
            gridssUnfilteredVcf = gridssUnfilteredVcf,
            diskSize = 35
    }
    
    output {
        IndexedVcf gridssVcf = GridssFilter.gridssVcf
    }
}
