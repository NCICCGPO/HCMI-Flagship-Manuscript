version 1.0

import "./wdl_structs.wdl"
import "calling/calling_wkf.wdl" as calling
import "calling/calling.wdl" as callingTasks
import "merge_vcf/merge_vcf_wkf.wdl" as mergeVcf
import "alignment_analysis/kourami_wfk.wdl" as kourami
import "alignment_analysis/msi_wkf.wdl" as msi
import "alignment_analysis/fastngsadmix_wkf.wdl" as fastNgsAdmix
import "pre_process/conpair_wkf.wdl" as conpair
import "pre_process/qc.wdl" as qc
import "annotate/annotate_wkf.wdl" as annotate
import "annotate/annotate_cnv_sv_wkf.wdl" as annotate_cnv_sv
import "germline/germline_wkf.wdl" as germline
import "annotate/germline_annotate_wkf.wdl" as germlineAnnotate
import "baf/baf_wkf.wdl" as baf
import "variant_analysis/deconstruct_sigs_wkf.wdl" as deconstructSigs
import "tasks/bam_cram_conversion.wdl" as cramConversion
import "tasks/reheader_bam_wkf.wdl" as reheaderBam
import "tasks/utils.wdl" as utils
import "tasks/mutect2_test_wkf.wdl" as mutect2Test
# ================== COPYRIGHT ================================================
# New York Genome Center
# SOFTWARE COPYRIGHT NOTICE AGREEMENT
# This software and its documentation are copyright (2021) by the New York
# Genome Center. All rights are reserved. This software is supplied without
# any warranty or guaranteed support whatsoever. The New York Genome Center
# cannot be responsible for its use, misuse, or functionality.
#
#    Jennifer M Shelton (jshelton@nygenome.org)
#    James Roche (jroche@nygenome.org)
#    Nico Robine (nrobine@nygenome.org)
#    Timothy Chu (tchu@nygenome.org)
#    Will Hooper (whooper@nygenome.org)
#    Minita Shah
#
# ================== /COPYRIGHT ===============================================


workflow SomaticDNA {
    input {
        Boolean local = false
        Boolean assumeCallingSpeedy = false

        BwaReference bwaReference
        IndexedReference referenceFa

        Boolean external = false
        Boolean production = true

        Array[PairInfo]+ pairInfos
        Array[SampleBamInfo]+ normalSampleBamInfos

        # For Tumor-Normal QC
        File markerBedFile
        File markerTxtFile

        # calling
        Array[String]+ listOfChromsFull
        Array[String]+ listOfChroms
        Array[String]+ callerIntervals
        Array[String]+ exomeCallerIntervals = callerIntervals
        Array[String]+ chrXCallerIntervals
        Array[String]+ exomeChrXCallerIntervals = chrXCallerIntervals
        IndexedTable callRegions
        Array[File] splitBedsWgs
        Map[String, File] chromBeds
        File lancetJsonLog
        File mantaJsonLog
        File strelkaJsonLog
        File mutectJsonLog
        File mutectJsonLogFilter
        File configureStrelkaSomaticWorkflow
        File intervalListBed
        File invertedIntervalListBed

        #   BicSeq2
        Int readLength
        Int coordReadLength
        Map[Int, Map[String, File]] uniqCoords
        File bicseq2ConfigFile
        File bicseq2SegConfigFile
        Map[String, File] chromFastas
        Int tumorMedianInsertSize = 400
        Int normalMedianInsertSize = 400
        Int lambda = 4

        # Gridss
        String bsGenome
        File ponTarGz
        Array[File] gridssAdditionalReference

        # merge callers
        File intervalListBed

        String library
        File ponWGSFile
        File ponExomeFile
        IndexedVcf gnomadBiallelic

        # kourami
        BwaReference kouramiReference
        File kouramiFastaGem1Index

        # mantis
        File mantisBed
        File intervalListBed

        #fastNgsAdmix
        File fastNgsAdmixChroms

        File fastNgsAdmixContinentalSites
        File fastNgsAdmixContinentalSitesBin
        File fastNgsAdmixContinentalSitesIdx
        File fastNgsAdmixContinentalRef
        File fastNgsAdmixContinentalNind

        File fastNgsAdmixPopulationSites
        File fastNgsAdmixPopulationSitesBin
        File fastNgsAdmixPopulationSitesIdx
        File fastNgsAdmixPopulationRef
        File fastNgsAdmixPopulationNind

        # annotation:
        String vepGenomeBuild
        Map[String, IndexedVcf] cosmicCodingChrom
        Map[String, IndexedVcf] cosmicNoncodingChrom
        Array[String]+ listOfChroms

        # Public
        Map[String, File] vepCacheChrom
        Map[String, File] annotationsChrom
        File plugins
        File dbNSFPReplacementLogic
        File MaxEntScan
        Map[String, IndexedTable] dbNSFP4Chrom
        Map[String, IndexedTable] dbscSNVChrom
        Map[String, IndexedVcf] gnomadGenomes
        Map[String, IndexedVcf] gnomadExomes
        IndexedReference vepFastaReference

        # Public
        File cancerResistanceMutations
        IndexedVcf deepIntronicsVcf
        IndexedVcf clinvarIntronicsVcf

        # annotate cnv
        File cytoBand
        File dgv
        File thousandG
        File cosmicUniqueBed
        File cancerCensusBed
        File ensemblUniqueBed

        # annotate sv
        String vepGenomeBuild
        # gap,DGV,1000G,PON,COSMIC
        File gap
        File dgvBedpe
        File thousandGVcf
        File svPon
        File cosmicBedPe

        # post annotation
        File cosmicCensus

        File ensemblEntrez

        # germline

        File excludeIntervalList
        Array[File] scatterIntervalsHcs

        IndexedVcf MillsAnd1000G
        IndexedVcf omni
        IndexedVcf hapmap
        IndexedVcf onekG
        IndexedVcf dbsnp

        IndexedVcf whitelist
        IndexedVcf nygcAf
        IndexedVcf pgx
        IndexedTable rwgsPgxBed
        IndexedVcf deepIntronicsVcf
        IndexedVcf clinvarIntronicsVcf
        IndexedVcf chdWhitelistVcf

        # signatures
        File cosmicSigs

        Boolean createCramBasedObjects = false

        Int gridssPreMemoryGb = 32
        Int gridssFilterMemoryGb = 32
        Boolean gridssHighMem = false
        Boolean mantaHighMem = false
        Boolean mutect2HighMem = false
        Boolean germlineHighMem = false

        Int annotateBicSeq2CnvMem = 36
        
        # need to create docker with gcloud
        File? serviceAccountKey
        String? gcpProject

    }
    if (local) {
        Boolean LocalAssumeCallingSpeedy = true
    }
    Boolean runAssumeCallingSpeedy = select_first([LocalAssumeCallingSpeedy, assumeCallingSpeedy])
    if (library == 'Exome') {
        Array[String]+ exomeRunCallerIntervals = exomeCallerIntervals
        Array[String]+ exomeChrXRunCallerIntervals = exomeChrXCallerIntervals
    }
    
    if (library == 'WGS') {
        Array[String]+ wgsRunCallerIntervals = callerIntervals
        Array[String]+ wgsChrXRunCallerIntervals = chrXCallerIntervals
    }
    
    Array[String]+ runCallerIntervals = select_first([exomeRunCallerIntervals, wgsRunCallerIntervals])
    Array[String]+ chrXRunCallerIntervals = select_first([exomeChrXRunCallerIntervals, wgsChrXRunCallerIntervals])

    # need to find UNIQUE bams (don't convert if part of more than one pair)
    call cramConversion.UniqueBams as uniqueBams {
        input:
            pairInfosJson = write_json(pairInfos)
    }

    scatter(bamInfo in uniqueBams.uniqueBams) {
        String alignmentFilename = basename(bamInfo.finalBam.bam)
        String cramAlignmentFilename = sub(basename(bamInfo.finalBam.bam), ".bam$", ".cram")
        if (alignmentFilename == cramAlignmentFilename) {
            String fileTypeCram = "cram"
        }
        if (alignmentFilename != cramAlignmentFilename) {
            String fileTypeBam = "bam"
        }
        String fileType = select_first([fileTypeCram, fileTypeBam])
        
        call reheaderBam.Reheader {
            input:
                finalBam = bamInfo.finalBam,
                referenceFa = referenceFa,
                sampleId = bamInfo.sampleId
        }
        
        if (fileType == "bam") {
            if (createCramBasedObjects) {
                call cramConversion.SamtoolsBamToCram as bamToCram {
                    input:
                        inputBam = Reheader.sampleBamMatched,
                        referenceFa = referenceFa,
                        sampleId = bamInfo.sampleId,
                        diskSize = (ceil(size(Reheader.sampleBamMatched.bam, "GB") * 1.7)) + 20 # 0.7 is estimated cram size
                }
            }
        }
        
        String newAlignmentFilename = basename(Reheader.sampleBamMatched.bam)
        if (alignmentFilename == newAlignmentFilename) {
            if (fileType == "cram") {
                Cram renamedFinalCram = object {
                    cram : Reheader.sampleBamMatched.bam,
                    cramIndex : Reheader.sampleBamMatched.bamIndex,
                }
                call cramConversion.SamtoolsCramToBam as cramToBam {
                    input:
                        inputCram = renamedFinalCram,
                        referenceFa = referenceFa,
                        sampleId = bamInfo.sampleId,
                        diskSize = (ceil(size(renamedFinalCram.cram, "GB") * 3)) + 20
                }
                Bam inputSampleBamMatch = select_first([cramToBam.bamInfo.finalBam, Reheader.sampleBamMatched])
            }
        }
        
        Bam inputSampleBamMatched = select_first([inputSampleBamMatch, Reheader.sampleBamMatched])

        call qc.ConpairPileup {
            input:
                markerBedFile = markerBedFile,
                referenceFa = referenceFa,
                finalBam = inputSampleBamMatched,
                sampleId = bamInfo.sampleId,
                memoryGb = 4,
                threads = 1,
                diskSize = ceil(size(inputSampleBamMatched.bam, "GB"))  + 20
       }

      String uniqueSampleIds = bamInfo.sampleId
    }
    if (createCramBasedObjects) {
        call cramConversion.UpdateCramInfos as updateCramInfo {
            input:
                pairInfosJson = write_json(pairInfos),
                normalInfosJson = write_json(normalSampleBamInfos),
                cramInfosJson = write_json(bamToCram.cramInfo)
        }
    }
    
    # confirm Calling speed is acceptable
    scatter(pairInfo in pairInfos) {
        call utils.GetIndex as tumorMutect2GetIndex {
            input:
                sampleIds = uniqueSampleIds,
                sampleId = pairInfo.tumorId
        }
        call utils.GetIndex as normalMutect2GetIndex {
            input:
                sampleIds = uniqueSampleIds,
                sampleId = pairInfo.normalId
        }
        PairInfo mutect2PairInfoObject = object {
            pairId : pairInfo.pairId,
            tumorFinalBam : inputSampleBamMatched[tumorMutect2GetIndex.index],
            normalFinalBam : inputSampleBamMatched[normalMutect2GetIndex.index],
            tumorId : pairInfo.tumorId,    # SM tag
            normalId : pairInfo.normalId   # SM tag
        }
        call mutect2Test.Mutect2RateTest {
            input:
                local = local,
                library = library,
                pairInfo = mutect2PairInfoObject,
                chrXCallerIntervals = chrXRunCallerIntervals,
                invertedIntervalListBed = invertedIntervalListBed,
                referenceFa = referenceFa,
                mutectJsonLog = mutectJsonLog,
                highMem = mutect2HighMem
        }
        if (Mutect2RateTest.mutect2Rate > 1000) {
            Boolean fastCostPass = true
        }
        Boolean costPassResult = select_first([fastCostPass, false])
        if (runAssumeCallingSpeedy || costPassResult ) {
            Boolean successCostPass = true
        }
        Boolean costPass = select_first([successCostPass, false])
        Array[File] mutect2ChrXRawVcfs = Mutect2RateTest.mutect2ChrXRawVcfs
        Array[File] mutect2ChrXRawStats = Mutect2RateTest.mutect2ChrXRawStats
        String rateTestNormals = pairInfo.normalId
        String rateTestPairIds = pairInfo.pairId
    }

    scatter (normalSampleBamInfo in normalSampleBamInfos) {
        String normalSampleIds = normalSampleBamInfo.sampleId
        
        call utils.GetIndex as normalGetIndex {
            input:
                sampleIds = uniqueSampleIds,
                sampleId = normalSampleBamInfo.sampleId
        }
        call utils.GetIndex as germlineMutect2RateGetIndex {
            input:
                sampleIds = rateTestNormals,
                sampleId = normalSampleBamInfo.sampleId
        }
        if (costPass[germlineMutect2RateGetIndex.index]) {
            call kourami.Kourami {
                input:
                    sampleId = normalSampleBamInfo.sampleId,
                    kouramiReference = kouramiReference,
                    finalBam = inputSampleBamMatched[normalGetIndex.index],
                    kouramiFastaGem1Index = kouramiFastaGem1Index,
                    referenceFa = referenceFa,
                    serviceAccountKey = serviceAccountKey,
                    gcpProject = gcpProject
            }

            call fastNgsAdmix.FastNgsAdmix as fastNgsAdmixContinental{
                input:
                    normalFinalBam = inputSampleBamMatched[normalGetIndex.index],
                    fastNgsAdmixSites = fastNgsAdmixContinentalSites,
                    fastNgsAdmixSitesBin = fastNgsAdmixContinentalSitesBin,
                    fastNgsAdmixSitesIdx = fastNgsAdmixContinentalSitesIdx,
                    fastNgsAdmixChroms = fastNgsAdmixChroms,
                    fastNgsAdmixRef = fastNgsAdmixContinentalRef,
                    fastNgsAdmixNind = fastNgsAdmixContinentalNind,
                    outprefix = normalSampleIds + "_continental"
            }

            call fastNgsAdmix.FastNgsAdmix as fastNgsAdmixPopulation{
                input:
                    normalFinalBam = inputSampleBamMatched[normalGetIndex.index],
                    fastNgsAdmixSites = fastNgsAdmixPopulationSites,
                    fastNgsAdmixSitesBin = fastNgsAdmixPopulationSitesBin,
                    fastNgsAdmixSitesIdx = fastNgsAdmixPopulationSitesIdx,
                    fastNgsAdmixChroms = fastNgsAdmixChroms,
                    fastNgsAdmixRef = fastNgsAdmixPopulationRef,
                    fastNgsAdmixNind = fastNgsAdmixPopulationNind,
                    outprefix = normalSampleIds + "population"
            }

            call germline.Germline {
                input:
                    finalBam = inputSampleBamMatched[normalGetIndex.index],
                    normal = normalSampleBamInfo.sampleId,
                    outputPrefix = normalSampleBamInfo.sampleId,
                    referenceFa = referenceFa,
                    listOfChroms = listOfChroms,
                    MillsAnd1000G = MillsAnd1000G,
                    hapmap = hapmap,
                    omni = omni,
                    onekG = onekG,
                    dbsnp = dbsnp,
                    nygcAf = nygcAf,
                    excludeIntervalList = excludeIntervalList,
                    scatterIntervalsHcs = scatterIntervalsHcs,
                    pgx = pgx,
                    rwgsPgxBed = rwgsPgxBed,
                    whitelist = whitelist,
                    chdWhitelistVcf = chdWhitelistVcf,
                    deepIntronicsVcf = deepIntronicsVcf,
                    clinvarIntronicsVcf = clinvarIntronicsVcf,
                    highMem = germlineHighMem
            }

            call germlineAnnotate.GermlineAnnotate as filteredGermlineAnnotate {
                input:
                    unannotatedVcf = Germline.haplotypecallerFinalFiltered,
                    production = production,
                    referenceFa = referenceFa,
                    normal = normalSampleBamInfo.sampleId,
                    listOfChroms = listOfChroms,
                    vepGenomeBuild = vepGenomeBuild,
                    cosmicCodingChrom = cosmicCodingChrom,
                    cosmicNoncodingChrom = cosmicNoncodingChrom,
                    dbNSFPReplacementLogic = dbNSFPReplacementLogic,
                    MaxEntScan = MaxEntScan,
                    dbNSFP4Chrom = dbNSFP4Chrom,
                    dbscSNVChrom = dbscSNVChrom,
                    gnomadGenomes = gnomadGenomes,
                    gnomadExomes = gnomadExomes,
                    # Public
                    cancerResistanceMutations = cancerResistanceMutations,
                    vepCacheChrom = vepCacheChrom,
                    annotationsChrom = annotationsChrom,
                    plugins = plugins,
                    vepFastaReference = vepFastaReference,
                    # Public
                    deepIntronicsVcf = deepIntronicsVcf,
                    clinvarIntronicsVcf = clinvarIntronicsVcf,
                    # post annotation
                    cosmicCensus = cosmicCensus,
                    ensemblEntrez = ensemblEntrez,
                    library = library
            }

            call germlineAnnotate.GermlineAnnotate as unFilteredGermlineAnnotate {
                input:
                    unannotatedVcf = Germline.haplotypecallerVcf,
                    haplotypecallerAnnotatedVcfPath = "~{normalSampleBamInfo.sampleId}.haplotypecaller.gatk.annotated.unfiltered.vcf",
                    production = production,
                    referenceFa = referenceFa,
                    normal = normalSampleBamInfo.sampleId,
                    listOfChroms = listOfChroms,
                    vepGenomeBuild = vepGenomeBuild,
                    cosmicCodingChrom = cosmicCodingChrom,
                    cosmicNoncodingChrom = cosmicNoncodingChrom,
                    dbNSFPReplacementLogic = dbNSFPReplacementLogic,
                    MaxEntScan = MaxEntScan,
                    dbNSFP4Chrom = dbNSFP4Chrom,
                    dbscSNVChrom = dbscSNVChrom,
                    gnomadGenomes = gnomadGenomes,
                    gnomadExomes = gnomadExomes,
                    # Public
                    cancerResistanceMutations = cancerResistanceMutations,
                    vepCacheChrom = vepCacheChrom,
                    annotationsChrom = annotationsChrom,
                    plugins = plugins,
                    vepFastaReference = vepFastaReference,
                    # Public
                    deepIntronicsVcf = deepIntronicsVcf,
                    clinvarIntronicsVcf = clinvarIntronicsVcf,
                    # post annotation
                    cosmicCensus = cosmicCensus,
                    ensemblEntrez = ensemblEntrez,
                    library = library
            }
        }
    }

    scatter(pairInfo in pairInfos) {
        call utils.GetIndex as germlineGetIndex {
            input:
                sampleIds = uniqueSampleIds,
                sampleId = pairInfo.normalId
        }
        
        call utils.GetIndex as tumorGetIndex {
            input:
                sampleIds = uniqueSampleIds,
                sampleId = pairInfo.tumorId
        }
        if ( size(unFilteredGermlineAnnotate.haplotypecallerAnnotatedVcf[germlineGetIndex.index]) > 0 ) {
            call baf.Baf {
                input:
                    referenceFa = referenceFa,
                    pairName = pairInfo.pairId,
                    sampleId = pairInfo.normalId,
                    tumorFinalBam = inputSampleBamMatched[tumorGetIndex.index],
                    normalFinalBam = inputSampleBamMatched[germlineGetIndex.index],
                    germlineVcf = unFilteredGermlineAnnotate.haplotypecallerAnnotatedVcf[germlineGetIndex.index],
                    serviceAccountKey = serviceAccountKey,
                    gcpProject = gcpProject
            }
        }
    }

    scatter(pairInfo in pairInfos) {
        call utils.GetIndex as tumorCallingGetIndex {
            input:
                sampleIds = uniqueSampleIds,
                sampleId = pairInfo.tumorId
        }

        call utils.GetIndex as normalCallingGetIndex {
            input:
                sampleIds = uniqueSampleIds,
                sampleId = pairInfo.normalId
        }
        call utils.GetIndex as mutect2RateGetIndex {
            input:
                sampleIds = rateTestPairIds,
                sampleId = pairInfo.pairId
        }
        if (costPass[mutect2RateGetIndex.index]) {
            # tumor insert size
            Int tumorDiskSize = ceil(size(inputSampleBamMatched[tumorCallingGetIndex.index].bam, "GB")) + 30

            call qc.MultipleMetrics as tumorMultipleMetrics {
                input:
                    referenceFa = referenceFa,
                    finalBam = inputSampleBamMatched[tumorCallingGetIndex.index],
                    sampleId = pairInfo.tumorId,
                    diskSize = tumorDiskSize
            }

            call callingTasks.GetInsertSize as tumorGetInsertSize {
                input:
                    insertSizeMetrics = tumorMultipleMetrics.insertSizeMetrics
            }

            # normal insert size
            Int normalDiskSize = ceil(size(inputSampleBamMatched[normalCallingGetIndex.index].bam, "GB")) + 30

            call qc.MultipleMetrics as normalMultipleMetrics {
                input:
                    referenceFa = referenceFa,
                    finalBam = inputSampleBamMatched[normalCallingGetIndex.index],
                    sampleId = pairInfo.normalId,
                    diskSize = normalDiskSize
            }

            call callingTasks.GetInsertSize as normalGetInsertSize {
                input:
                    insertSizeMetrics = normalMultipleMetrics.insertSizeMetrics
            }


            call conpair.Conpair {
                input:
                    tumorPileupsConpair = ConpairPileup.pileupsConpair[tumorCallingGetIndex.index],
                    normalPileupsConpair = ConpairPileup.pileupsConpair[normalCallingGetIndex.index],
                    tumor = pairInfo.tumorId,
                    normal = pairInfo.normalId,
                    pairName = pairInfo.pairId,
                    markerTxtFile = markerTxtFile
            }
            
            PairInfo callingPairInfo = object {
                    pairId : pairInfo.pairId,
                    tumorFinalBam : inputSampleBamMatched[tumorCallingGetIndex.index],
                    normalFinalBam : inputSampleBamMatched[normalCallingGetIndex.index],
                    tumorId : pairInfo.tumorId,
                    normalId : pairInfo.normalId
                }

            call calling.Calling {
                input:
                    mantaJsonLog = mantaJsonLog,
                    lancetJsonLog = lancetJsonLog,
                    mutectJsonLog = mutectJsonLog,
                    mutectJsonLogFilter = mutectJsonLogFilter,
                    strelkaJsonLog = strelkaJsonLog,
                    configureStrelkaSomaticWorkflow = configureStrelkaSomaticWorkflow,
                    intervalListBed = intervalListBed,
                    callerIntervals = runCallerIntervals,
                    invertedIntervalListBed = invertedIntervalListBed,
                    pairInfo = callingPairInfo,
                    listOfChroms = listOfChroms,
                    listOfChromsFull = listOfChromsFull,
                    referenceFa = referenceFa,
                    callRegions = callRegions,
                    mutect2ChrXRawStats = mutect2ChrXRawStats[mutect2RateGetIndex.index],
                    mutect2ChrXRawVcfs = mutect2ChrXRawVcfs[mutect2RateGetIndex.index],
                    bwaReference = bwaReference,
                    splitBedsWgs = splitBedsWgs,
                    readLength = readLength,
                    coordReadLength = coordReadLength,
                    uniqCoords = uniqCoords,
                    bicseq2ConfigFile = bicseq2ConfigFile,
                    bicseq2SegConfigFile = bicseq2SegConfigFile,
                    tumorMedianInsertSize = tumorGetInsertSize.insertSize,
                    normalMedianInsertSize = normalGetInsertSize.insertSize,
                    chromFastas = chromFastas,
                    bsGenome = bsGenome,
                    ponTarGz = ponTarGz,
                    gridssAdditionalReference = gridssAdditionalReference,
                    chromBeds = chromBeds,
                    library = library,
                    gridssPreMemoryGb = gridssPreMemoryGb,
                    gridssFilterMemoryGb = gridssFilterMemoryGb,
                    gridssHighMem = gridssHighMem,
                    mantaHighMem = mantaHighMem,
                    mutect2HighMem = mutect2HighMem,
                    serviceAccountKey = serviceAccountKey,
                    gcpProject = gcpProject
            }

            call msi.Msi {
                input:
                    normal = pairInfo.normalId,
                    pairName = pairInfo.pairId,
                    mantisBed = mantisBed,
                    intervalListBed = intervalListBed,
                    referenceFa = referenceFa,
                    tumorFinalBam = inputSampleBamMatched[tumorCallingGetIndex.index],
                    normalFinalBam = inputSampleBamMatched[normalCallingGetIndex.index]
            }

            PreMergedPairVcfInfo preMergedPairVcfInfo = object {
                pairId : pairInfo.pairId,
                filteredMantaSV : Calling.filteredMantaSV,
                strelka2Snv : Calling.strelka2Snv,
                strelka2Indel : Calling.strelka2Indel,
                mutect2 : Calling.mutect2,
                lancet : Calling.lancet,
                tumor : pairInfo.tumorId,
                normal : pairInfo.normalId,
                tumorFinalBam : inputSampleBamMatched[tumorCallingGetIndex.index],
                normalFinalBam : inputSampleBamMatched[normalCallingGetIndex.index]

            }

            PairRawVcfInfo pairRawVcfInfo = object {
                pairId : pairInfo.pairId,
                filteredMantaSV : Calling.filteredMantaSV,
                strelka2Snv : Calling.strelka2Snv,
                strelka2Indel : Calling.strelka2Indel,
                mutect2 : Calling.mutect2,
                lancet : Calling.lancet,
                gridssVcf : Calling.gridssVcf,
                bicseq2Png : Calling.bicseq2Png,
                bicseq2 : Calling.bicseq2,
                tumor : pairInfo.tumorId,
                normal : pairInfo.normalId,
                tumorFinalBam : inputSampleBamMatched[tumorCallingGetIndex.index],
                normalFinalBam : inputSampleBamMatched[normalCallingGetIndex.index]

            }

            if (library == 'WGS') {
                call mergeVcf.MergeVcf as wgsMergeVcf {
                    input:
                        external = external,
                        library = library,
                        preMergedPairVcfInfo = preMergedPairVcfInfo,
                        referenceFa = referenceFa,
                        listOfChroms = listOfChroms,
                        intervalListBed = intervalListBed,
                        ponFile = ponWGSFile,
                        serviceAccountKey = serviceAccountKey,
                        gcpProject = gcpProject
                }
            }

            if (library == 'Exome') {
                call mergeVcf.MergeVcf as exomeMergeVcf {
                    input:
                        external = external,
                        library = library,
                        preMergedPairVcfInfo = preMergedPairVcfInfo,
                        referenceFa = referenceFa,
                        listOfChroms = listOfChroms,
                        intervalListBed = intervalListBed,
                        ponFile = ponExomeFile,
                        serviceAccountKey = serviceAccountKey,
                        gcpProject = gcpProject
                }
            }

            File mergedVcf = select_first([wgsMergeVcf.mergedVcf, exomeMergeVcf.mergedVcf])

            call annotate.Annotate {
                input:
                    unannotatedVcf = mergedVcf,
                    referenceFa = referenceFa,
                    production = production,
                    tumorId = pairInfo.tumorId,
                    normalId = pairInfo.normalId,
                    pairName = pairInfo.pairId,
                    listOfChroms = listOfChroms,
                    vepGenomeBuild = vepGenomeBuild,
                    cosmicCodingChrom = cosmicCodingChrom,
                    cosmicNoncodingChrom = cosmicNoncodingChrom,
                    dbNSFPReplacementLogic = dbNSFPReplacementLogic,
                    MaxEntScan = MaxEntScan,
                    dbNSFP4Chrom = dbNSFP4Chrom,
                    dbscSNVChrom = dbscSNVChrom,
                    gnomadGenomes = gnomadGenomes,
                    gnomadExomes = gnomadExomes,
                    # Public
                    cancerResistanceMutations = cancerResistanceMutations,
                    vepCacheChrom = vepCacheChrom,
                    annotationsChrom = annotationsChrom,
                    plugins = plugins,
                    vepFastaReference = vepFastaReference,
                    # Public
                    deepIntronicsVcf = deepIntronicsVcf,
                    clinvarIntronicsVcf = clinvarIntronicsVcf,
                    # post annotation
                    cosmicCensus = cosmicCensus,
                    ensemblEntrez = ensemblEntrez,
                    library = library
            }

            call annotate_cnv_sv.AnnotateCnvSv {
                input:
                    tumor = pairRawVcfInfo.tumor,
                    normal = pairRawVcfInfo.normal,
                    pairName = pairRawVcfInfo.pairId,
                    listOfChroms =listOfChroms,
                    bicseq2 = pairRawVcfInfo.bicseq2,
                    cytoBand = cytoBand,
                    dgv = dgv,
                    thousandG = thousandG,
                    cosmicUniqueBed = cosmicUniqueBed,
                    cancerCensusBed = cancerCensusBed,
                    ensemblUniqueBed = ensemblUniqueBed,
                    filteredMantaSV = pairRawVcfInfo.filteredMantaSV,
                    gridssVcf = pairRawVcfInfo.gridssVcf,
                    vepGenomeBuild = vepGenomeBuild,
                    gap = gap,
                    dgvBedpe = dgvBedpe,
                    thousandGVcf = thousandGVcf,
                    svPon = svPon,
                    cosmicBedPe = cosmicBedPe
            }

            call deconstructSigs.DeconstructSig {
                input:
                    pairId = pairInfo.pairId,
                    mainVcf = mergedVcf,
                    cosmicSigs = cosmicSigs,
                    vepGenomeBuild = vepGenomeBuild
            }

            FinalVcfPairInfo finalVcfPairInfo = object {
                pairId : pairInfo.pairId,
                tumor : pairInfo.tumorId,
                normal : pairInfo.normalId,
                mainVcf : Annotate.pairVcfInfo.mainVcf,
                supplementalVcf : Annotate.pairVcfInfo.supplementalVcf,
                vcfAnnotatedTxt : Annotate.pairVcfInfo.vcfAnnotatedTxt,
                maf : Annotate.pairVcfInfo.maf,
                filteredMantaSV : Calling.filteredMantaSV,
                strelka2Snv : Calling.strelka2Snv,
                strelka2Indel : Calling.strelka2Indel,
                mutect2 : Calling.mutect2,
                lancet : Calling.lancet,
                gridssVcf : Calling.gridssVcf,
                bicseq2Png : Calling.bicseq2Png,
                bicseq2 : Calling.bicseq2,
                cnvAnnotatedFinalBed : AnnotateCnvSv.cnvAnnotatedFinalBed,
                cnvAnnotatedSupplementalBed : AnnotateCnvSv.cnvAnnotatedSupplementalBed,
                svFinalBedPe : AnnotateCnvSv.svFinalBedPe,
                svHighConfidenceFinalBedPe : AnnotateCnvSv.svHighConfidenceFinalBedPe,
                svSupplementalBedPe : AnnotateCnvSv.svSupplementalBedPe,
                svHighConfidenceSupplementalBedPe : AnnotateCnvSv.svHighConfidenceSupplementalBedPe
            }
        }
   }

    output {
        Array[Boolean] allCostPass = costPass
        # Germline
        Array[IndexedVcf?] haplotypecallerFinalFiltered = Germline.haplotypecallerFinalFiltered
        Array[File?] filteredHaplotypecallerAnnotatedVcf = filteredGermlineAnnotate.haplotypecallerAnnotatedVcf
        Array[File?] haplotypecallerAnnotatedVcf = unFilteredGermlineAnnotate.haplotypecallerAnnotatedVcf
        Array[File?] alleleCountsTxt = Baf.alleleCountsTxt
        Array[File?] kouramiResult = Kourami.result
        # CNV SV output and SNV INDELs
        Array[FinalVcfPairInfo?] finalVcfPairInfos = finalVcfPairInfo
        # MSI
        Array[File?] mantisWxsKmerCountsFinal = Msi.mantisWxsKmerCountsFinal
        Array[File?] mantisWxsKmerCountsFiltered = Msi.mantisWxsKmerCountsFiltered
        Array[File?] mantisExomeTxt = Msi.mantisExomeTxt
        Array[File?] mantisStatusFinal = Msi.mantisStatusFinal
        # ancestry
        Array[File?] beagleFileContinental = fastNgsAdmixContinental.beagleFile
        Array[File?] fastNgsAdmixQoptContinental = fastNgsAdmixContinental.fastNgsAdmixQopt
        Array[File?] beagleFilePopulation = fastNgsAdmixPopulation.beagleFile
        Array[File?] fastNgsAdmixQoptPopulation = fastNgsAdmixPopulation.fastNgsAdmixQopt
        # sigs
        Array[File?] sigs = DeconstructSig.sigs
        Array[File?] counts = DeconstructSig.counts
        Array[File?] sig_input = DeconstructSig.sigInput
        Array[File?] reconstructed = DeconstructSig.reconstructed
        Array[File?] diff = DeconstructSig.diff

        # Conpair
        Array[File?] concordanceAll = Conpair.concordanceAll
        Array[File?] concordanceHomoz = Conpair.concordanceHomoz
        Array[File?] contamination = Conpair.contamination
        Array[File?] pileupsConpair = ConpairPileup.pileupsConpair

        # Cram
         Array[SampleCramInfo?] crams = bamToCram.cramInfo
    }
}
