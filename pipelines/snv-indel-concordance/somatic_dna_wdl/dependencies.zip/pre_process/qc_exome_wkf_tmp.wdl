version 1.0


import "qc.wdl" as qc
import "../wdl_structs.wdl"

workflow QcMetricsExome {
    # command
    input {
        Bam finalBam
        IndexedReference referenceFa
        String sampleId
        File intervalList
        File refSeqGeneList
        File chromLengths
        IndexedVcf gnomadBiallelic
        File markerBedFile
        String outputDir = "."
    }

    Int additionalDiskSize = 10
    Int diskSize = ceil((size(finalBam.bam, "GB") + size(finalBam.bamIndex, "GB"))) +
                      additionalDiskSize

    call qc.DepthOfCoverageExome {
        input:
            referenceFa = referenceFa,
            finalBam = finalBam,
            sampleId = sampleId,
            outputDir = outputDir,
            intervalList = intervalList,
            refSeqGeneList = refSeqGeneList,
            diskSize = diskSize
    }

    output {
        File depthOfCoverageSampleSummary = DepthOfCoverageExome.depthOfCoverageSampleSummary
        File depthOfCoverageSampleStatistics = DepthOfCoverageExome.depthOfCoverageSampleStatistics
        File depthOfCoverageSampleGeneSummary = DepthOfCoverageExome.depthOfCoverageSampleGeneSummary
    }

}
