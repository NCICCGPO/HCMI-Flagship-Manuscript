version 1.0

import "./wdl_structs.wdl"
import "calling/mutect2_wkf.wdl" as mutect2
import "calling/calling_wkf.wdl" as calling
import "calling/calling.wdl" as callingTasks
import "merge_vcf/merge_vcf_wkf.wdl" as mergeVcf
import "alignment_analysis/kourami_wfk.wdl" as kourami
import "alignment_analysis/msi_wkf.wdl" as msi
import "alignment_analysis/fastngsadmix_wkf.wdl" as fastNgsAdmix
import "pre_process/conpair_wkf.wdl" as conpair
import "pre_process/qc.wdl" as qc
import "annotate/annotate_wkf.wdl" as annotate
import "annotate/annotate_cnv_sv_wkf.wdl" as annotate_cnv_sv
import "germline/germline_wkf.wdl" as germline
import "annotate/germline_annotate_wkf.wdl" as germlineAnnotate
import "baf/baf_wkf.wdl" as baf
import "variant_analysis/deconstruct_sigs_wkf.wdl" as deconstructSigs
import "tasks/bam_cram_conversion.wdl" as cramConversion
import "tasks/reheader_bam_wkf.wdl" as reheaderBam

import "tasks/utils.wdl" as utils

# ================== COPYRIGHT ================================================
# New York Genome Center
# SOFTWARE COPYRIGHT NOTICE AGREEMENT
# This software and its documentation are copyright (2021) by the New York
# Genome Center. All rights are reserved. This software is supplied without
# any warranty or guaranteed support whatsoever. The New York Genome Center
# cannot be responsible for its use, misuse, or functionality.
#
#    Jennifer M Shelton (jshelton@nygenome.org)
#    James Roche (jroche@nygenome.org)
#    Nico Robine (nrobine@nygenome.org)
#    Timothy Chu (tchu@nygenome.org)
#    Will Hooper (whooper@nygenome.org)
#    Minita Shah
#
# ================== /COPYRIGHT ===============================================


workflow SomaticBamWorkflow {
    input {
        Boolean local = false

        BwaReference bwaReference
        IndexedReference referenceFa

        Boolean external = false
        Boolean production = true

        Array[PairInfo]+ pairInfos
        Array[SampleBamInfo]+ normalSampleBamInfos

        # For Tumor-Normal QC
        File markerBedFile
        File markerTxtFile

        # calling
        Array[String]+ listOfChromsFull
        Array[String]+ listOfChroms
        Array[String]+ callerIntervals
        IndexedTable callRegions
        Map[String, File] chromBedsWgs
        Map[String, File] chromBeds
        File lancetJsonLog
        File mantaJsonLog
        File strelkaJsonLog
        File mutectJsonLog
        File mutectJsonLogFilter
        File configureStrelkaSomaticWorkflow
        File intervalListBed
        File invertedIntervalListBed

        #   BicSeq2
        Int readLength
        Int coordReadLength
        Map[Int, Map[String, File]] uniqCoords
        File bicseq2ConfigFile
        File bicseq2SegConfigFile
        Map[String, File] chromFastas
        Int tumorMedianInsertSize = 400
        Int normalMedianInsertSize = 400
        Int lambda = 4

        # Gridss
        String bsGenome
        File ponTarGz
        Array[File] gridssAdditionalReference

        # merge callers
        File intervalListBed

        String library
        File ponWGSFile
        File ponExomeFile
        IndexedVcf gnomadBiallelic

        IndexedVcf germFile

        # kourami
        BwaReference kouramiReference
        File kouramiFastaGem1Index

        # mantis
        File mantisBed
        File intervalListBed

        #fastNgsAdmix
        File fastNgsAdmixChroms

        File fastNgsAdmixContinentalSites
        File fastNgsAdmixContinentalSitesBin
        File fastNgsAdmixContinentalSitesIdx
        File fastNgsAdmixContinentalRef
        File fastNgsAdmixContinentalNind

        File fastNgsAdmixPopulationSites
        File fastNgsAdmixPopulationSitesBin
        File fastNgsAdmixPopulationSitesIdx
        File fastNgsAdmixPopulationRef
        File fastNgsAdmixPopulationNind

        # annotation:
        String vepGenomeBuild
        IndexedVcf cosmicCoding
        IndexedVcf cosmicNoncoding

        # Public
        File cancerResistanceMutations
        File vepCache
        File annotations
        File plugins
        String vepGenomeBuild
        IndexedReference vepFastaReference

        # NYGC-only
        IndexedVcf hgmdGene
        IndexedVcf hgmdUd10
        IndexedVcf hgmdPro
        IndexedVcf omimVcf

        # Public
        IndexedVcf chdGenesVcf
        IndexedVcf chdEvolvingGenesVcf
        IndexedVcf chdWhitelistVcf
        IndexedVcf deepIntronicsVcf
        IndexedVcf clinvarIntronicsVcf
        IndexedVcf masterMind

        # annotate cnv
        File cytoBand
        File dgv
        File thousandG
        File cosmicUniqueBed
        File cancerCensusBed
        File ensemblUniqueBed

        # annotate sv
        String vepGenomeBuild
        # gap,DGV,1000G,PON,COSMIC
        File gap
        File dgvBedpe
        File thousandGVcf
        File svPon
        File cosmicBedPe

        # post annotation
        File cosmicCensus

        File ensemblEntrez

        # germline

        File excludeIntervalList
        Array[File] scatterIntervalsHcs

        IndexedVcf MillsAnd1000G
        IndexedVcf omni
        IndexedVcf hapmap
        IndexedVcf onekG
        IndexedVcf dbsnp

        IndexedVcf whitelist
        IndexedVcf nygcAf
        IndexedVcf pgx
        IndexedTable rwgsPgxBed
        IndexedVcf deepIntronicsVcf
        IndexedVcf clinvarIntronicsVcf
        IndexedVcf chdWhitelistVcf

        # signatures
        File cosmicSigs

        Boolean createCramBasedObjects = false

        Int gridssPreMemoryGb = 32
        Int gridssFilterMemoryGb = 32
        Boolean gridssHighMem = false
        Boolean mantaHighMem = false
        Boolean mutect2HighMem = false
        Boolean germlineHighMem = false

        Int annotateBicSeq2CnvMem = 36

    }

    # need to find UNIQUE bams (don't convert if part of more than one pair)
    call cramConversion.UniqueBams as uniqueBams {
        input:
            pairInfosJson = write_json(pairInfos)
    }

    scatter(bamInfo in uniqueBams.uniqueBams) {
        String alignmentFilename = basename(bamInfo.finalBam.bam)
        String cramAlignmentFilename = sub(basename(bamInfo.finalBam.bam), ".bam$", ".cram")
        if (alignmentFilename == cramAlignmentFilename) {
            String fileTypeCram = "cram"
        }
        if (alignmentFilename != cramAlignmentFilename) {
            String fileTypeBam = "bam"
        }
        String fileType = select_first([fileTypeCram, fileTypeBam])
        
        call reheaderBam.Reheader {
            input:
                finalBam = bamInfo.finalBam,
                referenceFa = referenceFa,
                sampleId = bamInfo.sampleId
        }
        
        if (fileType == "bam") {
            if (createCramBasedObjects) {
                call cramConversion.SamtoolsBamToCram as bamToCram {
                    input:
                        inputBam = Reheader.sampleBamMatched,
                        referenceFa = referenceFa,
                        sampleId = bamInfo.sampleId,
                        diskSize = (ceil(size(Reheader.sampleBamMatched.bam, "GB") * 1.7)) + 20 # 0.7 is estimated cram size
                }
            }
        }
        
        String newAlignmentFilename = basename(Reheader.sampleBamMatched.bam)
        if (alignmentFilename == newAlignmentFilename) {
            if (fileType == "cram") {
                Cram renamedFinalCram = object {
                    cram : Reheader.sampleBamMatched.bam,
                    cramIndex : Reheader.sampleBamMatched.bamIndex,
                }
                call cramConversion.SamtoolsCramToBam as cramToBam {
                    input:
                        inputCram = renamedFinalCram,
                        referenceFa = referenceFa,
                        sampleId = bamInfo.sampleId,
                        diskSize = (ceil(size(renamedFinalCram.cram, "GB") * 3)) + 20
                }
                Bam inputSampleBamMatch = select_first([cramToBam.bamInfo.finalBam, Reheader.sampleBamMatched])
            }
        }
        
        Bam inputSampleBamMatched = select_first([inputSampleBamMatch, Reheader.sampleBamMatched])

      String uniqueSampleIds = bamInfo.sampleId
    }
    if (createCramBasedObjects) {
        call cramConversion.UpdateCramInfos as updateCramInfo {
            input:
                pairInfosJson = write_json(pairInfos),
                normalInfosJson = write_json(normalSampleBamInfos),
                cramInfosJson = write_json(bamToCram.cramInfo)
        }
    }

    scatter (normalSampleBamInfo in normalSampleBamInfos) {
        String normalSampleIds = normalSampleBamInfo.sampleId
        
        call utils.GetIndex as normalGetIndex {
            input:
                sampleIds = uniqueSampleIds,
                sampleId = normalSampleBamInfo.sampleId
        }
        
        call kourami.Kourami {
            input:
                sampleId = normalSampleBamInfo.sampleId,
                kouramiReference = kouramiReference,
                finalBam = inputSampleBamMatched[normalGetIndex.index],
                kouramiFastaGem1Index = kouramiFastaGem1Index,
                referenceFa = referenceFa
        }
    }

    scatter(pairInfo in pairInfos) {
        call utils.GetIndex as tumorCallingGetIndex {
            input:
                sampleIds = uniqueSampleIds,
                sampleId = pairInfo.tumorId
        }

        call utils.GetIndex as normalCallingGetIndex {
            input:
                sampleIds = uniqueSampleIds,
                sampleId = pairInfo.normalId
        }

        # tumor insert size
        Int tumorDiskSize = ceil(size(inputSampleBamMatched[tumorCallingGetIndex.index].bam, "GB")) + 30

        # normal insert size
        Int normalDiskSize = ceil(size(inputSampleBamMatched[normalCallingGetIndex.index].bam, "GB")) + 30
        
        PairInfo callingPairInfo = object {
                pairId : pairInfo.pairId,
                tumorFinalBam : inputSampleBamMatched[tumorCallingGetIndex.index],
                normalFinalBam : inputSampleBamMatched[normalCallingGetIndex.index],
                tumorId : pairInfo.tumorId,
                normalId : pairInfo.normalId
            }
        
        call mutect2.Mutect2 {
            input:
                tumor = pairInfo.tumorId,
                normal = pairInfo.normalId,
                pairName = pairInfo.pairId,
                normalFinalBam = inputSampleBamMatched[normalCallingGetIndex.index],
                tumorFinalBam = inputSampleBamMatched[tumorCallingGetIndex.index],
                mutectJsonLog = mutectJsonLog,
                mutectJsonLogFilter = mutectJsonLogFilter,
                callerIntervals = callerIntervals,
                invertedIntervalListBed = invertedIntervalListBed,
                referenceFa = referenceFa,
                library = library,
                highMem = mutect2HighMem
        }

        call msi.Msi {
            input:
                normal = pairInfo.normalId,
                pairName = pairInfo.pairId,
                mantisBed = mantisBed,
                intervalListBed = intervalListBed,
                referenceFa = referenceFa,
                tumorFinalBam = inputSampleBamMatched[tumorCallingGetIndex.index],
                normalFinalBam = inputSampleBamMatched[normalCallingGetIndex.index]
        }
   }

    output {
        Array[File] kouramiResult = Kourami.result
        
        # CNV SV output and SNV INDELs
        Array[File] mutect2 = Mutect2.mutect2
        # MSI
        Array[File] mantisWxsKmerCountsFinal = Msi.mantisWxsKmerCountsFinal
        Array[File] mantisWxsKmerCountsFiltered = Msi.mantisWxsKmerCountsFiltered
        Array[File] mantisExomeTxt = Msi.mantisExomeTxt
        Array[File] mantisStatusFinal = Msi.mantisStatusFinal

        # Cram
         Array[SampleCramInfo?] crams = bamToCram.cramInfo
    }
}
